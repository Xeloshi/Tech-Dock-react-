// npm create vite@latest .
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import { Carousel } from 'antd';

export default function ProductPage() {
    const params = useParams()
    console.log(params)
    const [product, setProduct] = useState({})
    
    useEffect(() => {
        async function getData() {
            const response = await fetch(`https://fakestoreapi.com/products/${params.id}`)
            const data = await response.json()
            setProduct(data)
        }

        getData()
    }, [])

    const carouselContentStyle = {
        margin: 0,
        height: '160px',
        color: '#fff',
        lineHeight: '160px',
        textAlign: 'center',
        background: '#364d79',
    };

    const onChange = currentSlide => {
        console.log(currentSlide);
    };

    return(
        <div className="max-w-6xl mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/2">
                    <div className="bg-gray-100 rounded-lg p-4 flex justify-center items-center">
                        <img 
                            src={product?.image}
                            className="w-full h-auto max-h-96 object-contain" 
                        />
                    </div>
                </div>
                <div className="md:w-1/2">
                    <h1 className="text-3xl font-bold mb-4">{product?.title}</h1>
                    
                    <div className="mb-6">
                        <p className="text-2xl font-bold text-red-500">${product?.price}</p>
                        <p className="text-gray-400 line-through">$9999999</p>
                    </div>
                    
                    <div className="mb-6">
                        <div className="flex items-center mb-2">
                            <div className="text-yellow-400">*****</div>
                            <span className="text-gray-600 ml-2">(24k reviews)</span>
                        </div>
                    </div>
                    
                    <div className="mb-6">
                        <p className="text-gray-700">{product?.description}</p>
                    </div>
                    
                    <button className="w-full bg-red-500 text-white py-3 rounded-lg font-bold hover:bg-red-600 transition-colors"> 
                        Add to Cart 
                    </button>
                </div>
            </div> 

            <div className="mt-12">
                <Carousel afterChange={onChange}>
                    <div>
                        <h3 style={carouselContentStyle}>1</h3>
                    </div>
                    <div>
                        <h3 style={carouselContentStyle}>2</h3>
                    </div>
                    <div>
                        <h3 style={carouselContentStyle}>3</h3>
                    </div>
                    <div>
                        <h3 style={carouselContentStyle}>4</h3>
                    </div>
                </Carousel>
            </div>
        </div>
    )
}
// --------------------------------------------------------------------------------------------------------------------
// import { useState, useEffect } from "react";
// import { useParams } from "react-router";

// export default function(){
//     const params = useParams()
//     const [product, setProduct] = useState({})

//     useEffect(() => {
//         async function getData() {
//             const response = await fetch(`https://dummyjson.com/products/${params.id}`)
//             const data = await response.json()
//             setProduct(data)
//         }

//         getData()
//     }, [params.id])

//     return(
//         <div className="max-w-6xl mx-auto px-4 py-8">
//             <div className="flex flex-col md:flex-row gap-8">
//                 <div className="md:w-1/2">
//                     <div className="bg-gray-100 rounded-lg p-4 flex justify-center items-center">
//                         <img 
//                             src={product.thumbnail} 
//                             className="w-full h-auto max-h-96 object-contain" 
//                         />
//                     </div>
//                 </div>
//                 <div className="md:w-1/2">
//                     <h1 className="text-3xl font-bold mb-4">{product.title}</h1>
                    
//                     <div className="mb-6">
//                         <p className="text-2xl font-bold text-red-500">${product.price}</p>
//                     </div>
                    
//                     <div className="mb-6">
//                         <div className="flex items-center mb-2">
//                             <div className="text-yellow-400">{"*".repeat(Math.round(product.rating))}</div>
//                             <span className="text-gray-600 ml-2">({product.rating})</span>
//                         </div>
//                     </div>
                    
//                     <div className="mb-6">
//                         <p className="text-gray-700">{product.description}</p>
//                     </div>
                    
//                     <button className="w-full bg-red-500 text-white py-3 rounded-lg font-bold hover:bg-red-600 transition-colors"> 
//                         Add to Cart 
//                     </button>
//                 </div>
//             </div>
//         </div>
//     )
// }