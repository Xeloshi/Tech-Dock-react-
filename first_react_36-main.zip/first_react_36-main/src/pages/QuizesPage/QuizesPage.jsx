export default function QuizesPage() {
    return (
        <div>QuizesPage</div>
    )
}