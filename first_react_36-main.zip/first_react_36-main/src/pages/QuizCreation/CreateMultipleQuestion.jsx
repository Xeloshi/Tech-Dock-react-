export default function CreateMultipleQuestion() {
  return (
    <div>CreateMultipleQuestion</div>
  )
}
