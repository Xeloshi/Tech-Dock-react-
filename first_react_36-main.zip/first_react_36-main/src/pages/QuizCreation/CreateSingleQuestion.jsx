export default function CreateSingleQuestion() {
  return (
    <div>CreateSingleQuestion</div>
  )
}
