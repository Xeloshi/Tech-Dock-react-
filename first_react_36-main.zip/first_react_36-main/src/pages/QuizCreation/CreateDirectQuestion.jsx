import { Input } from "antd"

export default function CreateDirectQuestion() {
  return (
    <div>
      <label>
        <p>Текст вопроса</p>
        <Input type="text" placeholder="Вопрос"/>
        <p>Правильный ответ</p>
        <Input type="text" placeholder="Ответ"/>
      </label>
    </div>
  )
}
