import { useEffect, useState } from "react";
import { NavLink } from "react-router";

export default function IndexPage() {
    const [products, setProducts] = useState([])

    useEffect(() => {
        async function getData() {
            const response = await fetch('https://fakestoreapi.com/products')
            const data = await response.json()
            setProducts(data.slice(0, 5))
        }

        getData()
    }, [])

    return (
        <div className="p-4 ml-5">
            <h2 className="text-2xl font-bold mb-10">Flash Sales</h2>

            <div className="flex gap-4 overflow-x-auto">
                {products.map((product) => (
                    <NavLink key={product.id} to={`/products/${product.id}`}>
                        <div className="bg-gray-100 rounded p-3  justify-center">
                            <img src={product.image}></img>
                        </div>
                        
                        <h3 className="font-bold">{product.title}</h3>
                        <p className="text-red-500 font-bold">${product.price}</p>
                        <p className="text-gray-400 line-through">$9999999</p>
                        <div className="text-yellow-400">***** (67)</div>
                    </NavLink>
                ))}
            </div>
            <button className="w-full bg-red-500 text-white py-1 rounded max-w-60 h-15 mt-10 ml-150">
                View All Products
            </button>
            <p><NavLink to="/admin" className="mt-4 inline-block">В админку!</NavLink></p>
        </div>
    )
}
// --------------------------------------------------------------------------------------------------------------------
// import { useEffect, useState } from "react";
// import { NavLink } from "react-router";

// export default function IndexPage() {
//     const [products, setProducts] = useState([])

//     useEffect(() => {
//         async function getData() {
//             const response = await fetch('https://dummyjson.com/products')
//             const data = await response.json()
//             setProducts(data.products)
//         }

//         getData()
//     }, [])

//     const handleDelete = (productId) => {
//         setProducts(prevProducts => 
//             prevProducts.filter(product => product.id !== productId)
//         )
//     }

//     return (
//         <div className="p-4">
//             <h2 className="text-2xl font-bold mb-10">All Products</h2>

//             <div className="grid grid-cols-3 gap-4">
//                 {products.map((product) => (
//                     <div 
//                         key={product.id} 
//                         className="bg-gray-100 rounded p-3"
//                         onDoubleClick={() => handleDelete(product.id)}
//                     >
//                         <img 
//                             src={product.thumbnail} 
//                             className="w-full h-64 object-contain"
//                         />
                        
//                         <h3 className="font-bold">{product.title}</h3>
//                         <p className="text-red-500 font-bold">${product.price}</p>
//                         <div className="text-yellow-400">{"*".repeat(Math.round(product.rating))}</div>
//                     </div>
//                 ))}
//             </div>
//         </div>
//     )
// }